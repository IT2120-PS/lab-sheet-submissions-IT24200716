getwd()
setwd("C:/Users/kavin/Desktop/IT24200716M")

##question 1
##i
##Binomial Distribution
##Here,random variable X has Binomial distribution with n=50 and p=0,85
1-pbinom(46,50,0.85,lower.tail = TRUE)
##question2
#i)X=number of calls in one hour
#ii)Poisson distribution
#Here,random variable x has poisson distribution with lambda=12
dpois(15,12)

